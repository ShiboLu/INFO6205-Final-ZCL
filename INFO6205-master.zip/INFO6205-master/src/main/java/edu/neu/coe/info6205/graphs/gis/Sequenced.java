package edu.neu.coe.info6205.graphs.gis;

public interface Sequenced {

    int getSequence();

    void setSequence(int sequence);
}
